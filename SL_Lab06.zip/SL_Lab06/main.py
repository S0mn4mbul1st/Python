from configparser import ConfigParser
import configparser
import os


def read_configuration():
    if not os.path.exists('lab6.config'):
        return
    else:
        configuration = ConfigParser()
        configuration.read("lab6.config")

        logFile = configuration["LogFile"]
        config = configuration["Config"]
        display = configuration["Display"]

        if logFile["name"] == "":
            logFile["name"] = "access log-00000000"
        if config["debug"] == "":
            config["debug"] = "Default Debug"
        if display["lines"] == "":
            display["lines"] = "4"
        if display["separator"] == "":
            display["separator"] = "/"
        if display["filter"] == "":
            display["filter"] = "GET"

        print(logFile["name"])
        print(config["debug"])
        print(display["lines"])
        print(display["separator"])
        print(display["filter"])


def content_reader():
    try:
        if os.path.exists('lab6.config'):
            file = open('lab6.config', 'r')
            lines = file.read().splitlines()
            return lines
    except OSError:
        print("Could not open/read file")


def content_analyzer():
    list = []
    addressData = []
    timeStampData = []
    requestData = []
    statusCodeData = []
    sizeData = []

    for line in content_reader():
        addressData = line.split(" - - ")
        timeStampData = line.split(' ')
        requestData = line.split('"')
        statusCodeData = line.split('"-"')
        sizeData = line.split('(')

    list.append((addressData, timeStampData,
                 requestData, statusCodeData, sizeData))

    return list


def print_all_requests(subnet):
    len = 240745 // 16 + 8
    counter = 0
    for index in content_analyzer()[0]:
        if subnet == index:
            print(index)
        if (counter + 1) // len == 0:
            input("Press Enter to continue...")


def byte_counter():
    tot_bytes = 0
    dictionary = dict()

    for data in content_reader():
        key = data[4]
        value = data[8]
        dictionary[key].append(value)
        tot_bytes += value

    return dictionary

