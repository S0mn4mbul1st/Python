import logging


def run():

    b = open('log.txt', 'r')

    c = b.readlines()

    for line in c:
        num = int(line.split(' ')[2])

    b.close()


if __name__ == '__main__':
    run()

a = []
b = []
c = []
d = []


def read_log():

    b = open('log.txt', 'r')

    c = b.readlines()

    container = [line.rstrip() for line in b]

    lines = 0

    for line in container:
        if line != '\n':
            ls = line.split('')
            numA = ls[0]
            numB = int(ls[1])
            numC = int(ls[2])
            numD = int(ls[3])

        lines += 1

        a.append(numA)
        b.append(numB)
        c.append(numC)
        d.append(numD)

    logging.warning('Amount of Lines: ' + lines)
    logging.warning('Entries: ' + lines)


def successful_reads(nList):

    logging.info(len(nList))

    i = 0

    for line in nList:
        if line == '404':
            nList[i].pop
        i += 1
    return nList


def failed_reads(nList):

    fList = []
    sList = []
    for line in nList:
        for i in line.split():
            if i.startswith("5"):
                fList.append(i)
            if i.startswith("4"):
                sList.append(i)
    finL = fList + sList

    logging.info(len(fList))
    logging.info(len(sList))
    return finL


def html_entries(nList):
    l = []
    for line in nList:
        if (line.find(".html")):
            l.append(line)
    return l


def print_html_entries(nList):
    l = []
    for line in nList:
        if (line.find(".html")):
            l.append(line)
    print(*l, sep=", ")
