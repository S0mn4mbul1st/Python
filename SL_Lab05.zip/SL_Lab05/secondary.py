import main
import sys
import logging
import json
import logging.handlers
import os

from main import jsonConfig

def read_json():
    try:
        with open('storage.json') as c:
            return json.load(c)
    except FileNotFoundError:
        print("Error: File name or location doesn't match.")


def setLogLevel():
    handler = logging.handlers.WatchedFileHandler(
        os.environ.get("lvl", "storage.json"))
    formatter = logging.Formatter(logging.BASIC_FORMAT)
    handler.setFormatter(formatter)
    root = logging.getLogger()
    root.setLevel(os.environ.get("lvl"))
    root.addHandler(handler)


def run():
    with open('storage.txt') as file:
        read_log()
        request()
        findAddress()
        print(f"MaxReq:\n{maxReq()}.")
        read_json()
        setLogLevel()
        printLogs(read_json()['params']['limit'])
        printRequest('/index.xml')
        printMethod(read_json()['params']['method'])


if _name_ == "_main_":
    jsonConfig()
    run()


def read_log():
    dictionary = {}
    with open('storage.txt') as file:
        content = file.readlines()
    for line in content:
        key = line.split(" - - ")[1][:-1]
        if key not in dictionary.keys():
            dictionary[key] = line.split()[0]
    return dictionary


def request():
    dLog = sorted(read_log().values())
    dID = {}
    for address in dLog:
        if address in dLog:
            dID[address] = dLog.count(address)
    return dID


def findMaxAddress():
        maxi = sorted(request().values())[-1]
        print(fJson"\nMax request {maxi}: ")
        for key, value in request().items():
            if value == maxi:
                print(f"\t{key}\t")


def maxReq():
    data = list(read_log().keys())
    maxi = 0
    for index in data:
        val = index.split('] \"')[1][:-1]
        if len(val) > maxi:
            maxi = len(val)
            ans = val
    return ans


def printRequest(str):
    lReq = []
    for log in list(read_log().keys()):
        if str in log:
            lReq.append(log.split('] \"')[1])
    for index in lReq:
        print(index)
    input("Waiting for a user to press a key...")


def printMethod(method):
    methodList = []
    for log in list(read_log().keys()):
        if method in log:
            methodList.append(log)

    n = read_json()['params']['lineLimit']
    temp = [methodList[i * n:(i + 1) * n]
            for i in range((len(methodList) + n - 1) // n)]
    for index in temp:
        for j in index:
            print(j)
        input("Waiting for a user to press a key...")


def printLogs(limit):
    logList = []
    for log in list(read_log().keys()):
        if limit < len(log):
            logList.append(log)
    data = read_json()['params']['lineLimit']
    temp = [logList[index * data:(index + 1) * data]
            for index in range((len(logList) + data - 1) // data)]
    for index in temp:
        for j in index:
            print(j)
        input("Waiting for a user to press a key...")
