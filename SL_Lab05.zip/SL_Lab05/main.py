import sys
import logging
import json
import logging.handlers
import os

def jsonConfig():
    log = input('\nEnter the name of webserver log: ')
    method = input('Enter the name of one of the HTTP request methods: ')
    lvl = input('Enter the logging lvl used by the application: ')
    lineLimit = int(
        input('Enter the number of log lines to be displayed at once: '))
    limit = int(input('Enter the size limit of file: '))
    params = {'params': {'log': log, 'method': method,
                         'lvl': lvl, 'lineLimit': lineLimit, 'limit': limit}}
    with open('storage.json', 'w') as fJson:
        json.dump(params, fJson, indent=5)
