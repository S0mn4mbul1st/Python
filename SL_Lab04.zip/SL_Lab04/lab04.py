import os
import sys

with open('log.txt', 'r') as file:

    def run():
        read_log()

    if __name__ == '__lab04__':
        run()

    dictionary = {}

    def read_log():

        for line in file:

            splitLine = line.split()

            dictionary[int(splitLine[0])] = " ".join(splitLine[1:])

        return dictionary

    def ip_requests():

        for line in file:

            splitLine = line.split()

            dictionary[int(splitLine[0])] = " ".join(splitLine[1:])

        return dictionary

    def ip_find():
        num_list = []

        for line in file.readlines():
           num_list.append(int((line.split(''))[8]))

        return max(num_list)
  
    def longest_request():
        addresses = []

        for line in file.readlines():
           addresses.append(int((line.split('"'))[1]))

        return max(addresses, key=len)

    def non_existent():
        list = []

        for line in file.readlines():
            if "Page not found" in line:
             list.append(line)

        return list

    file.close
