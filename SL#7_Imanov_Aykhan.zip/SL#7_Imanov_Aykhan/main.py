import re
import datetime
from builtins import FileNotFoundError


list = []


class Malformed:
    exception = FileNotFoundError


def read_log():
    try:
      data = open("log.txt")
      for line in data:
        list.append(line)
      return list

    except FileNotFoundError:
        print("Invalid Path")


def datetime_object_creator(logs):
    for line in logs:
        element = re.findall("[^ ]*", line)
        date = (element[6])[1:]
        day, month, fraction = re.split("/", date)
        month = {"Jan": "01", "Feb": "02", "Mar": "03",
                 "Apr": "04", "May": "05", "Jun": "06",
                 "Jul": "07", "Aug": "08", "Sep": "09",
                 "Oct": "10", "Nov": "11", "Dec": "12"}[month]
        year, hour, mins, sec = re.split(":", fraction)
        new_datetime = datetime.datetime(
            int(year), int(month), int(day), int(hour), int(mins), int(sec)
        )
        return new_datetime


class HTTP_request:
    def __init__(self, http_resource, http_request_method):
        self.http_resource = http_resource
        self.http_request_method = http_request_method

    def to_string(self, obj):
        print(
            f"Resource: {self.http_resource}/nRequest: {self.http_request_method}/n"
        )

    def get_request_method(self):
        return self.http_request_method

    def get_requested_resource(self):
        return self.http_resource


class Log:
    def __init__(self, log):
        self.log = log

    def to_string(self, obj):
        print(f"{self.log}\n")


def log_object_creator(logs):
    try:
        log_entry = re.split('"', logs)[-2]
        obj = Log(log_entry)
        return obj

    except Malformed.exception:
        raise


def get_list(list):
    feedback_obj = []
    for line in list:
        log_entry = re.split('"', line)[-2]
        log_en = Log(log_entry)
        feedback_obj.append(log_en)
    return feedback_obj


def message_displayer(start, end, list):
    if start > end:
        print("Error")

    else:
        for line in list:
            elements = re.findall("[^ ]*", line)
            date = (elements[6])[1:]
            day, month, fraction = re.split("/", date)
            month = {"Jan": "01", "Feb": "02", "Mar": "03",
                     "Apr": "04", "May": "05", "Jun": "06",
                     "Jul": "07", "Aug": "08", "Sep": "09",
                     "Oct": "10", "Nov": "11", "Dec": "12"}[month]
            year, hour, mins, sec = re.split(":", fraction)
            datetime_object = datetime.datetime(
                int(year), int(month), int(day), int(hour), int(mins), int(sec)
            )
            if start <= datetime_object <= end:
                print(line)


def test_package():
    list_log = read_log()
    start = datetime.datetime(2000, 1, 1, 12, 00, 00)
    end = datetime.datetime(2020, 11, 25, 12, 00, 00)
    message_displayer(start, end, list_log)


test_package()